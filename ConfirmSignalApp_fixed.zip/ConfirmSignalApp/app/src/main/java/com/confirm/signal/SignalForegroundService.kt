package com.confirm.signal

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import com.confirm.signal.data.AppDatabase
import com.confirm.signal.data.Prefs
import com.confirm.signal.data.SignalEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class SignalForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private lateinit var prefs: Prefs
    private lateinit var db: AppDatabase

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        db = AppDatabase.getInstance(this)
        NotificationHelper.ensureChannels(this)
        startForeground(NotificationHelper.SERVICE_NOTIF_ID, NotificationHelper.buildServiceNotification(this, "মনিটরিং শুরু হচ্ছে…"))
        prefs.serviceRunning = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (job == null || job?.isActive != true) {
            job = serviceScope.launch { loop() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        prefs.serviceRunning = false
        job?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private suspend fun CoroutineScope.loop() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        while (isActive) {
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ConfirmSignal:poll")
            try {
                wl.acquire(20_000)
                runCycle()
            } catch (e: Exception) {
                updateNotif("সংযোগ ত্রুটি: ${e.message ?: "unknown"}")
            } finally {
                if (wl.isHeld) wl.release()
            }
            val pollSec = prefs.pollSeconds.coerceIn(5, 60)
            delay(pollSec * 1000L)
        }
    }

    private suspend fun runCycle() {
        checkNewDay()

        val symbol = prefs.symbol
        val source = prefs.dataSource

        val m1: List<Candle>
        val m5: List<Candle>
        when (source) {
            "crypto" -> {
                m1 = NetworkClients.fetchBinanceKlines(symbol, "1m", 100)
                m5 = NetworkClients.fetchBinanceKlines(symbol, "5m", 60)
            }
            "oanda" -> {
                val key = prefs.apiKey
                if (key.isBlank()) { updateNotif("OANDA access token নেই — অ্যাপে সেট করুন"); return }
                val instrument = symbol.replace("/", "_")
                m1 = NetworkClients.fetchOandaCandles(instrument, "M1", 100, key)
                m5 = NetworkClients.fetchOandaCandles(instrument, "M5", 60, key)
            }
            "yahoo" -> {
                val ticker = symbol.replace("/", "") + "=X"
                m1 = NetworkClients.fetchYahooCandles(ticker, "1m", "1d")
                m5 = NetworkClients.fetchYahooCandles(ticker, "5m", "5d")
            }
            else -> {
                val key = prefs.apiKey
                if (key.isBlank()) { updateNotif("Twelve Data API key নেই — অ্যাপে সেট করুন"); return }
                m1 = NetworkClients.fetchTwelveDataKlines(symbol, "1m", 100, key)
                m5 = NetworkClients.fetchTwelveDataKlines(symbol, "5m", 60, key)
            }
        }

        if (m1.size < 25 || m5.size < 2) { updateNotif("$symbol: অপর্যাপ্ত ডেটা"); return }

        // Grade any pending signals for this symbol using the latest live price
        val liveClose = m1.last().close
        gradePending(symbol, liveClose)

        val closedM1 = m1.dropLast(1) // exclude currently-forming candle
        if (closedM1.size < 24) { updateNotif("$symbol: অপেক্ষা করছে…"); return }

        val closes1 = closedM1.map { it.close }
        val last = closedM1.last()
        val prev3 = closedM1.takeLast(4).dropLast(1)
        if (prev3.size < 3) { updateNotif("$symbol: অপেক্ষা করছে…"); return }

        val closes5 = m5.map { it.close }
        val emaArr = Indicators.ema(closes5, 50)
        val emaNow = emaArr.last()
        val price5m = closes5.last()

        val rsiArr = Indicators.rsi(closes1, 14)
        val rsiNow = rsiArr.last()
        val rsiPrev = rsiArr[rsiArr.size - 2]

        val bb = Indicators.bollinger(closes1, 20, 2.0)
        val lowerNow = bb.lower.last()
        val upperNow = bb.upper.last()

        val avgBody = prev3.map { Math.abs(it.close - it.open) }.average()
        val signalBody = Math.abs(last.close - last.open)
        val strongBody = signalBody > avgBody * 0.75 // relaxed from 1.0x
        val bullish = last.close > last.open
        val bearish = last.close < last.open

        val trendUp = price5m > emaNow
        val trendDown = price5m < emaNow

        // RSI: relaxed thresholds (35/65) + look back over the last 3 transitions instead of
        // requiring the cross on this exact bar.
        val rsiTail = rsiArr.takeLast(4)
        var rsiCrossUp = false
        var rsiCrossDown = false
        for (i in 1 until rsiTail.size) {
            val a = rsiTail[i - 1]
            val b = rsiTail[i]
            if (a != null && b != null) {
                if (a < 35 && b >= 35 && b < 70) rsiCrossUp = true
                if (a > 65 && b <= 65 && b > 30) rsiCrossDown = true
            }
        }

        val bbTolerance = 0.0008
        val lowerBounce = lowerNow != null && last.low <= lowerNow * (1 + bbTolerance)
        val upperReject = upperNow != null && last.high >= upperNow * (1 - bbTolerance)

        val showCall = trendUp
        val callConfirms = listOf(rsiCrossUp, lowerBounce, strongBody && bullish)
        val putConfirms = listOf(rsiCrossDown, upperReject, strongBody && bearish)
        val activeConfirms = if (showCall) callConfirms else putConfirms
        val trendOk = if (showCall) trendUp else trendDown
        val allPass = trendOk && activeConfirms.count { it } >= 2

        updateNotif("$symbol লাইভ: ${formatPrice(liveClose)}")

        if (allPass && last.openTime != prefs.lastSignalBarTime && prefs.signalsFiredToday < prefs.maxSignalsPerDay) {
            fireSignal(if (showCall) "CALL" else "PUT", symbol, liveClose, last.openTime)
        }
    }

    private suspend fun gradePending(symbol: String, latestPrice: Double) {
        val now = System.currentTimeMillis()
        val pending = db.signalDao().getPending().filter { it.symbol == symbol && now >= it.expiryAt }
        for (r in pending) {
            val status = when {
                latestPrice == r.entryPrice -> "draw"
                r.direction == "CALL" -> if (latestPrice > r.entryPrice) "win" else "loss"
                else -> if (latestPrice < r.entryPrice) "win" else "loss"
            }
            db.signalDao().update(r.copy(exitPrice = latestPrice, status = status))
        }
    }

    private suspend fun fireSignal(direction: String, symbol: String, entryPrice: Double, barTime: Long) {
        prefs.lastSignalBarTime = barTime
        prefs.signalsFiredToday += 1

        val record = SignalEntity(
            id = "sig_${System.currentTimeMillis()}_${Random.nextInt(10000)}",
            time = System.currentTimeMillis(),
            symbol = symbol,
            direction = direction,
            entryPrice = entryPrice,
            expiryAt = System.currentTimeMillis() + prefs.expiryMinutes * 60_000L,
            exitPrice = null,
            status = "pending"
        )
        db.signalDao().insert(record)

        if (!prefs.muted) {
            NotificationHelper.sendSignalNotification(
                this,
                "$direction সিগন্যাল — $symbol",
                "এন্ট্রি ${formatPrice(entryPrice)} • ${prefs.expiryMinutes}মি এক্সপায়ারি",
                notifId = System.currentTimeMillis().toInt()
            )
        }
    }

    private fun checkNewDay() {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = sdf.format(Date())
        if (prefs.lastSignalDay != today) {
            prefs.lastSignalDay = today
            prefs.signalsFiredToday = 0
        }
    }

    private fun formatPrice(p: Double): String =
        if (p < 10) String.format(Locale.US, "%.4f", p) else String.format(Locale.US, "%.2f", p)

    private fun updateNotif(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NotificationHelper.SERVICE_NOTIF_ID, NotificationHelper.buildServiceNotification(this, text))
    }
}
