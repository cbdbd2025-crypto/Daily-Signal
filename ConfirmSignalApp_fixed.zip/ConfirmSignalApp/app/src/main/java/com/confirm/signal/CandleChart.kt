package com.confirm.signal

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandleChart(
    candles: List<Candle>,
    bbUpper: List<Double?>,
    bbLower: List<Double?>,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val gridColor = Color(0xFF7E9389).copy(alpha = 0.15f)
    val bandColor = Color(0xFFF0B429).copy(alpha = 0.55f)
    val lastLineColor = Color(0xFFE7EEEA).copy(alpha = 0.4f)
    val upColor = Color(0xFF35D08E)
    val downColor = Color(0xFFFF5D5D)
    val labelPaint = android.graphics.Paint().apply {
        color = android.graphics.Color.rgb(126, 147, 137)
        isAntiAlias = true
    }

    Canvas(modifier = modifier.fillMaxWidth().height(210.dp)) {
        val n = candles.size
        if (n < 2) return@Canvas

        val padL = 4f
        val padR = with(density) { 46.dp.toPx() }
        val padT = with(density) { 10.dp.toPx() }
        val padB = with(density) { 10.dp.toPx() }
        val plotW = size.width - padL - padR
        val plotH = size.height - padT - padB

        var lo = Double.POSITIVE_INFINITY
        var hi = Double.NEGATIVE_INFINITY
        candles.forEach { lo = min(lo, it.low); hi = max(hi, it.high) }
        bbUpper.forEach { v -> if (v != null) hi = max(hi, v) }
        bbLower.forEach { v -> if (v != null) lo = min(lo, v) }
        if (hi == lo) { hi += 1; lo -= 1 }
        val padVal = (hi - lo) * 0.08
        hi += padVal; lo -= padVal

        fun xFor(i: Int) = padL + (i.toFloat() / (n - 1)) * plotW
        fun yFor(p: Double) = (padT + (1 - (p - lo) / (hi - lo)) * plotH).toFloat()

        val slotW = plotW / n
        val bodyW = max(2f, slotW * 0.6f)

        labelPaint.textSize = with(density) { 10.sp.toPx() }

        for (g in 0..3) {
            val p = lo + (hi - lo) * (g / 3.0)
            val y = yFor(p)
            drawLine(gridColor, Offset(padL, y), Offset(size.width - padR, y), strokeWidth = 1f)
            val label = if (p < 10) String.format(Locale.US, "%.4f", p) else String.format(Locale.US, "%.2f", p)
            drawContext.canvas.nativeCanvas.drawText(label, size.width - padR + 4f, y + 3f, labelPaint)
        }

        fun drawBandLine(arr: List<Double?>) {
            var started = false
            var prevX = 0f
            var prevY = 0f
            arr.forEachIndexed { i, v ->
                if (v != null) {
                    val x = xFor(i)
                    val y = yFor(v)
                    if (started) drawLine(bandColor, Offset(prevX, prevY), Offset(x, y), strokeWidth = 1f)
                    prevX = x; prevY = y; started = true
                }
            }
        }
        drawBandLine(bbUpper)
        drawBandLine(bbLower)

        candles.forEachIndexed { i, c ->
            val x = xFor(i)
            val up = c.close >= c.open
            val color = if (up) upColor else downColor
            drawLine(color, Offset(x, yFor(c.high)), Offset(x, yFor(c.low)), strokeWidth = 1f)
            val yO = yFor(c.open)
            val yC = yFor(c.close)
            val top = min(yO, yC)
            val h = max(1f, abs(yO - yC))
            drawRect(color, topLeft = Offset(x - bodyW / 2, top), size = Size(bodyW, h))
        }

        val lastClose = candles.last().close
        val yLast = yFor(lastClose)
        drawLine(
            lastLineColor,
            Offset(padL, yLast), Offset(size.width - padR, yLast),
            strokeWidth = 1f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
        )
    }
}
