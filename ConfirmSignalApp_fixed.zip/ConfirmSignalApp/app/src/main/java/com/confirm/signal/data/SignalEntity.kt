package com.confirm.signal.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey val id: String,
    val time: Long,
    val symbol: String,
    val direction: String,   // CALL | PUT
    val entryPrice: Double,
    val expiryAt: Long,
    val exitPrice: Double?,
    val status: String       // pending | win | loss | draw
)
