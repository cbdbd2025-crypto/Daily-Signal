package com.confirm.signal

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.confirm.signal.data.AppDatabase
import com.confirm.signal.data.Prefs
import com.confirm.signal.data.SignalEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---- Theme colors (mirrors the HTML mockup's CSS variables) ----
private val BG = Color(0xFF0A0F0D)
private val PANEL = Color(0xFF101613)
private val PANEL_2 = Color(0xFF151D19)
private val LINE = Color(0xFF223028)
private val TXT = Color(0xFFE7EEEA)
private val MUTED = Color(0xFF7E9389)
private val GREEN = Color(0xFF35D08E)
private val GREEN_DIM = Color(0xFF1C4A38)
private val RED = Color(0xFFFF5D5D)
private val RED_DIM = Color(0xFF4A1C1F)
private val AMBER = Color(0xFFF0B429)

class MainActivity : ComponentActivity() {

    private lateinit var prefs: Prefs
    private lateinit var db: AppDatabase
    private val activityScope = CoroutineScope(Dispatchers.IO)

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        db = AppDatabase.getInstance(this)
        NotificationHelper.ensureChannels(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = GREEN)) {
                AppRoot(
                    prefs = prefs,
                    historyFlow = db.signalDao().observeAll(),
                    onStart = { startForegroundServiceNow() },
                    onStop = { stopForegroundServiceNow() },
                    onClearData = { clearData() },
                    onRequestBatteryExemption = { requestBatteryExemption() }
                )
            }
        }
    }

    private fun startForegroundServiceNow() {
        val intent = Intent(this, SignalForegroundService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopForegroundServiceNow() {
        stopService(Intent(this, SignalForegroundService::class.java))
        prefs.serviceRunning = false
    }

    private fun clearData() {
        activityScope.launch { db.signalDao().clearAll() }
    }

    private fun requestBatteryExemption() {
        try {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } catch (e: Exception) { /* no-op: some OEMs block this intent */ }
    }
}

@Composable
fun AppRoot(
    prefs: Prefs,
    historyFlow: Flow<List<SignalEntity>>,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onClearData: () -> Unit,
    onRequestBatteryExemption: () -> Unit
) {
    val history by historyFlow.collectAsState(initial = emptyList())

    var source by remember { mutableStateOf(prefs.dataSource) }
    var symbol by remember { mutableStateOf(prefs.symbol) }
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var pollSec by remember { mutableStateOf(prefs.pollSeconds.toString()) }
    var expiryMin by remember { mutableStateOf(prefs.expiryMinutes.toString()) }
    var maxSignals by remember { mutableStateOf(prefs.maxSignalsPerDay.toString()) }
    var running by remember { mutableStateOf(prefs.serviceRunning) }
    var muted by remember { mutableStateOf(prefs.muted) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var settingsExpanded by remember { mutableStateOf(false) }
    var periodTab by remember { mutableStateOf("day") }

    val symbols = SymbolLists.forSource(source)

    fun persistSettings() {
        prefs.dataSource = source
        prefs.symbol = symbol
        prefs.apiKey = apiKey
        prefs.pollSeconds = pollSec.toIntOrNull()?.coerceIn(5, 60) ?: 15
        prefs.expiryMinutes = expiryMin.toIntOrNull()?.coerceIn(1, 15) ?: 1
        prefs.maxSignalsPerDay = maxSignals.toIntOrNull()?.coerceIn(1, 10) ?: 2
    }

    // ---- Live visual loop: fetches + computes chart/checklist while this screen is open.
    // Actual signal firing / DB logging / notifications stay in SignalForegroundService.
    var cycle by remember { mutableStateOf<SignalEngine.CycleResult?>(null) }
    var connLive by remember { mutableStateOf(false) }
    var connText by remember { mutableStateOf("connecting…") }
    var bannerVisible by remember { mutableStateOf(false) }
    var bannerDirection by remember { mutableStateOf("CALL") }
    var bannerText by remember { mutableStateOf("") }
    var localLastBarTime by remember { mutableStateOf(0L) }

    LaunchedEffect(source, symbol, apiKey, pollSec) {
        while (isActive) {
            try {
                val result = SignalEngine.runCycle(source, symbol, apiKey)
                cycle = result
                connLive = true
                connText = "live"
                if (result.allPass && result.lastOpenTime != localLastBarTime) {
                    localLastBarTime = result.lastOpenTime
                    bannerDirection = if (result.showCall) "CALL" else "PUT"
                    bannerText = "এন্ট্রি ${formatPrice(result.lastClose)} • ${expiryMin}মি এক্সপায়ারি"
                    bannerVisible = true
                }
            } catch (e: Exception) {
                connLive = false
                connText = "সংযোগ বিচ্ছিন্ন — পুনঃচেষ্টা হচ্ছে"
            }
            val sec = (pollSec.toIntOrNull() ?: 15).coerceIn(5, 60)
            delay(sec * 1000L)
        }
    }

    LaunchedEffect(bannerVisible) {
        if (bannerVisible) {
            delay(6000)
            bannerVisible = false
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = BG) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            HeaderBar(
                connLive = connLive,
                connText = connText,
                muted = muted,
                onToggleMute = { muted = !muted; prefs.muted = muted }
            )

            Spacer(Modifier.height(14.dp))
            WarningBox()

            Spacer(Modifier.height(14.dp))
            SourceBar(
                source = source,
                onSourceChange = {
                    source = it
                    symbol = SymbolLists.defaultFor(it)
                    persistSettings()
                }
            )

            if (source == "forex") {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; persistSettings() },
                    label = { Text("Twelve Data API key") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "ফ্রি key: twelvedata.com → Sign up → Dashboard থেকে কপি করুন",
                    color = MUTED, fontSize = 10.5.sp
                )
            } else if (source == "oanda") {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it; persistSettings() },
                    label = { Text("OANDA personal access token") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "ফ্রি: oanda.com → \"Try a free demo\" → লগইন করে My Services → Manage API Access → Generate Token",
                    color = MUTED, fontSize = 10.5.sp
                )
            } else if (source == "yahoo") {
                Spacer(Modifier.height(8.dp))
                Text(
                    "key/সাইনআপ লাগে না — কিন্তু এটা Yahoo-র অফিসিয়াল API না, তাই যেকোনো সময় বন্ধ/পরিবর্তন হতে পারে",
                    color = MUTED, fontSize = 10.5.sp
                )
            }

            Spacer(Modifier.height(10.dp))
            ChipRow(
                items = symbols,
                selected = symbol,
                display = { it.replace("USDT", "/USDT") },
                onSelect = { symbol = it; persistSettings() }
            )

            Spacer(Modifier.height(16.dp))
            HeroPrice(
                pair = symbol,
                priceText = cycle?.let { formatPrice(it.liveClose) } ?: "—",
                changeText = cycle?.let { "${if (it.changePct >= 0) "▲" else "▼"} ${String.format(Locale.US, "%.3f", Math.abs(it.changePct))}% (1m)" } ?: "—",
                up = (cycle?.changePct ?: 0.0) >= 0
            )

            if (bannerVisible) {
                Spacer(Modifier.height(16.dp))
                SignalBanner(direction = bannerDirection, symbol = symbol, subtitle = bannerText)
            }

            Spacer(Modifier.height(16.dp))
            Panel {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionTitle("লাইভ ক্যান্ডেল চার্ট")
                    Text("1m", color = GREEN, fontSize = 11.sp, fontFamily = MonoFamily)
                }
                Spacer(Modifier.height(10.dp))
                val c = cycle
                if (c != null && c.chartCandles.size >= 2) {
                    CandleChart(candles = c.chartCandles, bbUpper = c.chartBbUpper, bbLower = c.chartBbLower)
                } else {
                    Box(modifier = Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                        Text("চার্ট লোড হচ্ছে…", color = MUTED, fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Panel {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionTitle("নিশ্চিতকরণ চেকলিস্ট")
                    Text(cycle?.bias ?: "—", color = TXT, fontSize = 11.sp, fontFamily = MonoFamily)
                }
                Spacer(Modifier.height(6.dp))
                val items = cycle?.checklist
                if (items == null) {
                    listOf("ট্রেন্ড (EMA50, 5m)", "RSI ক্রস (14, 1m)", "Bollinger Band বাউন্স", "স্ট্রং ক্যান্ডেল বডি").forEach {
                        ChecklistRow(pass = null, label = it, sub = "অপেক্ষা করছে…")
                    }
                } else {
                    items.forEach { ChecklistRow(pass = it.pass, label = it.label, sub = it.sub) }
                }
            }

            Spacer(Modifier.height(16.dp))
            Panel {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SectionTitle("সিগন্যাল লগ (আজ)")
                    TextButton(onClick = { showClearConfirm = true }) {
                        Text("🗑 সব ডাটা মুছুন", color = RED)
                    }
                }
                Spacer(Modifier.height(6.dp))
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val todays = history.filter { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(it.time)) == today }
                if (todays.isEmpty()) {
                    Text("এখনো কোনো সিগন্যাল আসেনি", color = MUTED, fontSize = 12.sp, modifier = Modifier.padding(vertical = 16.dp))
                } else {
                    todays.take(200).forEach { r -> SignalRow(r) }
                }
            }

            Spacer(Modifier.height(16.dp))
            Panel {
                SectionTitle("পারফরম্যান্স")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("day" to "দৈনিক", "week" to "সাপ্তাহিক", "month" to "মাসিক", "year" to "বাৎসরিক").forEach { (k, label) ->
                        PeriodTab(selected = periodTab == k, label = label, onClick = { periodTab = k }, modifier = Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(12.dp))

                val start = periodStartMillis(periodTab)
                val graded = history.filter { it.time >= start && (it.status == "win" || it.status == "loss") }
                val wins = graded.count { it.status == "win" }
                val losses = graded.count { it.status == "loss" }
                val total = wins + losses

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatBox("WIN", wins.toString(), GREEN, Modifier.weight(1f))
                    StatBox("LOSS", losses.toString(), RED, Modifier.weight(1f))
                    StatBox("WIN RATE", if (total > 0) "${wins * 100 / total}%" else "—", TXT, Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(18.dp))
            Panel {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { settingsExpanded = !settingsExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("সেটিংস", color = MUTED, fontSize = 11.5.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily)
                    Text(if (settingsExpanded) "▲" else "▼", color = MUTED, fontSize = 11.sp)
                }
                if (settingsExpanded) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        if (running) "● ব্যাকগ্রাউন্ড মনিটরিং চলছে" else "○ ব্যাকগ্রাউন্ড মনিটরিং বন্ধ",
                        color = if (running) GREEN else MUTED, fontSize = 12.sp
                    )
                    Text(
                        "চালু থাকলে বর্তমান সোর্সের সবকটা সিম্বল (${symbols.joinToString(", ")}) একসাথে মনিটর হবে — শুধু সিলেক্ট করা একটা না",
                        color = MUTED, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { persistSettings(); onStart(); running = true },
                        enabled = !running, modifier = Modifier.fillMaxWidth()
                    ) { Text("▶ ব্যাকগ্রাউন্ডে মনিটরিং শুরু করুন") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { onStop(); running = false },
                        enabled = running, modifier = Modifier.fillMaxWidth()
                    ) { Text("■ বন্ধ করুন") }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onRequestBatteryExemption, modifier = Modifier.fillMaxWidth()) {
                        Text("🔋 ব্যাটারি অপ্টিমাইজেশন থেকে বাদ দিন (রিলায়াবিলিটির জন্য)")
                    }

                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = maxSignals, onValueChange = { maxSignals = it; persistSettings() }, label = { Text("দিনে ম্যাক্স") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = pollSec, onValueChange = { pollSec = it }, label = { Text("পোল (সে.)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = expiryMin, onValueChange = { expiryMin = it; persistSettings() }, label = { Text("এক্সপায়ারি (মি.)") }, modifier = Modifier.weight(1f))
                    }
                    Button(
                        onClick = { persistSettings() },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                    ) { Text("সেটিংস সেভ করুন") }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "ডেমো/শিক্ষামূলক ব্যবহারের জন্য — কোনো আর্থিক পরামর্শ নয়",
                color = MUTED, fontSize = 10.5.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(30.dp))
        }
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("সব ডাটা মুছে ফেলবেন?") },
            text = { Text("এই কাজ আর ফেরানো যাবে না — সব সিগন্যাল হিস্টোরি ও স্ট্যাটস মুছে যাবে।") },
            confirmButton = {
                TextButton(onClick = { onClearData(); showClearConfirm = false }) {
                    Text("হ্যাঁ, মুছে দিন", color = RED)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("বাতিল") }
            }
        )
    }
}

private val MonoFamily = androidx.compose.ui.text.font.FontFamily.Monospace

@Composable
private fun Panel(content: @Composable () -> Unit) {
    Surface(
        color = PANEL,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LINE),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = MUTED, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily, letterSpacing = 1.sp)
}

@Composable
private fun HeaderBar(connLive: Boolean, connText: String, muted: Boolean, onToggleMute: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(RoundedCornerShape(50))
                    .background(if (connLive) GREEN else RED)
            )
            Column {
                Text("CONFIRM", color = TXT, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily)
                Text(connText, color = MUTED, fontSize = 11.sp, fontFamily = MonoFamily)
            }
        }
        Surface(
            color = PANEL, shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, LINE),
            modifier = Modifier.clickable { onToggleMute() }
        ) {
            Text(if (muted) "🔕" else "🔔", modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp), fontSize = 16.sp)
        }
    }
}

@Composable
private fun WarningBox() {
    Surface(
        color = Color(0xFF14100A),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3A2C10)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            "সতর্কতা: এই টুল শুধু নিয়ম-ভিত্তিক অ্যালার্ট দেয়, কোনো ট্রেড এক্সিকিউট করে না এবং কোনো ফলাফলের নিশ্চয়তা দেয় না। ১ মিনিট চার্টে কোনো ইন্ডিকেটরই \"সিওর\" না। শুধু ডেমো/লার্নিং উদ্দেশ্যে ব্যবহার করুন। ডেটা সোর্স: Binance পাবলিক API (ক্রিপ্টো পেয়ার — ফরেক্স লাইভ ডেটা ফ্রি-তে পাওয়া যায় না, ব্রোকার লাইসেন্স লাগে)।",
            color = Color(0xFFD9B662), fontSize = 11.5.sp, lineHeight = 16.sp,
            modifier = Modifier.padding(10.dp)
        )
    }
}

@Composable
private fun SourceBar(source: String, onSourceChange: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Chip(text = "Binance", selected = source != "forex" && source != "oanda" && source != "yahoo", onClick = { onSourceChange("crypto") })
        Chip(text = "ফরেক্স (Twelve Data)", selected = source == "forex", onClick = { onSourceChange("forex") })
        Chip(text = "OANDA (ডেমো)", selected = source == "oanda", onClick = { onSourceChange("oanda") })
        Chip(text = "Yahoo Finance (key লাগে না)", selected = source == "yahoo", onClick = { onSourceChange("yahoo") })
    }
}

@Composable
private fun ChipRow(items: List<String>, selected: String, display: (String) -> String, onSelect: (String) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { s ->
            Chip(text = display(s), selected = s == selected, onClick = { onSelect(s) })
        }
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) GREEN_DIM else PANEL,
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) GREEN else LINE),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text,
            color = if (selected) GREEN else MUTED,
            fontFamily = MonoFamily,
            fontSize = 12.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun HeroPrice(pair: String, priceText: String, changeText: String, up: Boolean) {
    Surface(
        color = PANEL_2,
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LINE),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(pair, color = MUTED, fontSize = 12.sp, fontFamily = MonoFamily, letterSpacing = 1.sp)
            Spacer(Modifier.height(6.dp))
            Text(priceText, color = if (up) GREEN else RED, fontSize = 36.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily)
            Spacer(Modifier.height(2.dp))
            Text(changeText, color = if (up) GREEN else RED, fontSize = 13.sp, fontFamily = MonoFamily)
        }
    }
}

@Composable
private fun SignalBanner(direction: String, symbol: String, subtitle: String) {
    val isCall = direction == "CALL"
    Surface(
        color = if (isCall) Color(0xFF0D2317) else Color(0xFF241010),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isCall) GREEN else RED),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "$direction — $symbol",
                color = if (isCall) GREEN else RED,
                fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily, letterSpacing = 2.sp
            )
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = MUTED, fontSize = 11.sp, fontFamily = MonoFamily)
        }
    }
}

@Composable
private fun ChecklistRow(pass: Boolean?, label: String, sub: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(11.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 9.dp)
    ) {
        val boxColor = when (pass) { true -> GREEN; false -> RED_DIM; null -> Color.Transparent }
        val borderColor = when (pass) { true -> GREEN; false -> RED; null -> LINE }
        val symbolText = when (pass) { true -> "✓"; false -> "✕"; null -> "–" }
        val symbolColor = when (pass) { true -> Color(0xFF06140D); false -> RED; null -> MUTED }
        Surface(
            color = boxColor, shape = RoundedCornerShape(6.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
            modifier = Modifier.height(20.dp)
        ) {
            Box(modifier = Modifier.padding(horizontal = 5.dp), contentAlignment = Alignment.Center) {
                Text(symbolText, color = symbolColor, fontSize = 12.sp)
            }
        }
        Column {
            Text(label, color = TXT, fontSize = 13.sp)
            Text(sub, color = MUTED, fontSize = 10.5.sp, fontFamily = MonoFamily)
        }
    }
}

@Composable
private fun PeriodTab(selected: Boolean, label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        color = if (selected) GREEN_DIM else PANEL,
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) GREEN else LINE),
        modifier = modifier.clickable { onClick() }
    ) {
        Text(
            label,
            color = if (selected) GREEN else MUTED,
            fontFamily = MonoFamily, fontSize = 11.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp)
        )
    }
}

@Composable
fun StatBox(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(color = PANEL_2, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 12.dp).fillMaxWidth()
        ) {
            Text(value, color = color, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily)
            Text(label, color = MUTED, fontSize = 10.sp, fontFamily = MonoFamily)
        }
    }
}

@Composable
fun SignalRow(r: SignalEntity) {
    val statusColor = when (r.status) {
        "win" -> GREEN
        "loss" -> RED
        "pending" -> AMBER
        else -> MUTED
    }
    val dirColor = if (r.direction == "CALL") GREEN else RED
    Surface(
        color = Color(0xFF101613),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(r.direction, color = dirColor, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = MonoFamily)
            Text(r.symbol, color = TXT, fontSize = 12.sp, fontFamily = MonoFamily)
            Text(r.status.uppercase(Locale.US), color = statusColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = MonoFamily)
            Text(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(r.time)), color = MUTED, fontSize = 11.sp, fontFamily = MonoFamily)
        }
    }
}

fun periodStartMillis(period: String): Long {
    val cal = Calendar.getInstance()
    when (period) {
        "day" -> {
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        }
        "week" -> {
            cal.firstDayOfWeek = Calendar.MONDAY
            cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        }
        "month" -> {
            cal.set(Calendar.DAY_OF_MONTH, 1)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        }
        else -> { // year
            cal.set(Calendar.DAY_OF_YEAR, 1)
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        }
    }
    return cal.timeInMillis
}
