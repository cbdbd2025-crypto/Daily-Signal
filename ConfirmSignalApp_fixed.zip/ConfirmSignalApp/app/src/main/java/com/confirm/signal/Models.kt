package com.confirm.signal

import java.util.Locale

data class Candle(
    val openTime: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double
)

fun formatPrice(p: Double): String =
    if (p < 10) String.format(Locale.US, "%.4f", p) else String.format(Locale.US, "%.2f", p)
