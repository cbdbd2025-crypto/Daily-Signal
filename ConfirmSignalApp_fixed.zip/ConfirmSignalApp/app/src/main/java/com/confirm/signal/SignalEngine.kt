package com.confirm.signal

/**
 * Pure computation layer shared by the live UI (MainActivity) and the background
 * SignalForegroundService. No side effects (no DB writes, no notifications) —
 * callers decide what to do with the result.
 */
object SignalEngine {

    data class ChecklistItem(val pass: Boolean, val label: String, val sub: String)

    data class CycleResult(
        val chartCandles: List<Candle>,
        val chartBbUpper: List<Double?>,
        val chartBbLower: List<Double?>,
        val liveClose: Double,
        val changePct: Double,
        val bias: String,
        val showCall: Boolean,
        val checklist: List<ChecklistItem>,
        val allPass: Boolean,
        val lastOpenTime: Long,
        val lastClose: Double
    )

    // 5-minute candles barely change inside a 15-60s poll window, so we cache them
    // per (source, symbol) for 60s. This roughly halves the API calls we burn per
    // cycle — important for rate-limited free tiers like Twelve Data (8 req/min).
    private var m5CacheKey: String? = null
    private var m5CacheTime: Long = 0L
    private var m5Cache: List<Candle>? = null

    private suspend fun getM5(source: String, symbol: String, apiKey: String): List<Candle> {
        val key = "$source|$symbol"
        val now = System.currentTimeMillis()
        val cached = m5Cache
        if (cached != null && m5CacheKey == key && now - m5CacheTime < 60_000L) {
            return cached
        }
        val fresh = when (source) {
            "crypto" -> NetworkClients.fetchBinanceKlines(symbol, "5m", 60)
            "oanda" -> NetworkClients.fetchOandaCandles(symbol.replace("/", "_"), "M5", 60, apiKey)
            "yahoo" -> NetworkClients.fetchYahooCandles(toYahooTicker(symbol), "5m", "5d")
            else -> NetworkClients.fetchTwelveDataKlines(symbol, "5m", 60, apiKey)
        }
        m5CacheKey = key; m5CacheTime = now; m5Cache = fresh
        return fresh
    }

    private fun toYahooTicker(symbol: String): String = symbol.replace("/", "") + "=X"

    suspend fun runCycle(source: String, symbol: String, apiKey: String): CycleResult {
        val m1: List<Candle>
        val m5: List<Candle>
        when (source) {
            "crypto" -> {
                m1 = NetworkClients.fetchBinanceKlines(symbol, "1m", 100)
                m5 = getM5(source, symbol, apiKey)
            }
            "oanda" -> {
                if (apiKey.isBlank()) throw Exception("OANDA personal access token নেই")
                val instrument = symbol.replace("/", "_")
                m1 = NetworkClients.fetchOandaCandles(instrument, "M1", 100, apiKey)
                m5 = getM5(source, symbol, apiKey)
            }
            "yahoo" -> {
                m1 = NetworkClients.fetchYahooCandles(toYahooTicker(symbol), "1m", "1d")
                m5 = getM5(source, symbol, apiKey)
            }
            else -> {
                if (apiKey.isBlank()) throw Exception("Twelve Data API key নেই")
                m1 = NetworkClients.fetchTwelveDataKlines(symbol, "1m", 100, apiKey)
                m5 = getM5(source, symbol, apiKey)
            }
        }
        if (m1.size < 25 || m5.size < 2) throw Exception("অপর্যাপ্ত ডেটা")

        val closedM1 = m1.dropLast(1) // exclude currently-forming candle
        if (closedM1.size < 24) throw Exception("অপেক্ষা করছে…")

        val closes1 = closedM1.map { it.close }
        val last = closedM1.last()
        val prev3 = closedM1.takeLast(4).dropLast(1)
        if (prev3.size < 3) throw Exception("অপেক্ষা করছে…")

        val closes5 = m5.map { it.close }
        val emaArr = Indicators.ema(closes5, 50)
        val emaNow = emaArr.last()
        val price5m = closes5.last()

        val rsiArr = Indicators.rsi(closes1, 14)
        val rsiNow = rsiArr.last()
        val rsiPrev = rsiArr[rsiArr.size - 2]

        val bb = Indicators.bollinger(closes1, 20, 2.0)
        val lowerNow = bb.lower.last()
        val upperNow = bb.upper.last()

        val avgBody = prev3.map { Math.abs(it.close - it.open) }.average()
        val signalBody = Math.abs(last.close - last.open)
        val strongBody = signalBody > avgBody * 0.75 // relaxed from 1.0x
        val bullish = last.close > last.open
        val bearish = last.close < last.open

        val trendUp = price5m > emaNow
        val trendDown = price5m < emaNow

        // RSI: relaxed thresholds (35/65 instead of 30/70) and look back over the last
        // 3 candle-to-candle transitions instead of requiring the cross on this exact bar.
        val rsiTail = rsiArr.takeLast(4)
        var rsiCrossUp = false
        var rsiCrossDown = false
        for (i in 1 until rsiTail.size) {
            val a = rsiTail[i - 1]
            val b = rsiTail[i]
            if (a != null && b != null) {
                if (a < 35 && b >= 35 && b < 70) rsiCrossUp = true
                if (a > 65 && b <= 65 && b > 30) rsiCrossDown = true
            }
        }

        // Bollinger Band: small tolerance instead of requiring an exact touch this bar.
        val bbTolerance = 0.0008 // ~0.08%
        val lowerBounce = lowerNow != null && last.low <= lowerNow * (1 + bbTolerance)
        val upperReject = upperNow != null && last.high >= upperNow * (1 - bbTolerance)

        val showCall = trendUp
        val bias = if (trendUp) "CALL bias" else if (trendDown) "PUT bias" else "neutral"

        val callConfirms = listOf(rsiCrossUp, lowerBounce, strongBody && bullish)
        val putConfirms = listOf(rsiCrossDown, upperReject, strongBody && bearish)
        val activeConfirms = if (showCall) callConfirms else putConfirms

        val callPass = listOf(trendUp) + callConfirms
        val putPass = listOf(trendDown) + putConfirms
        val active = if (showCall) callPass else putPass

        // Relaxed rule: trend must align, and at least 2-of-3 of the remaining confirmations
        // (was: all 4 required). This fires noticeably more often while staying trend-filtered.
        val trendOk = if (showCall) trendUp else trendDown
        val confirmCount = activeConfirms.count { it }
        val allPass = trendOk && confirmCount >= 2

        val checklist = listOf(
            ChecklistItem(
                pass = active[0],
                label = "ট্রেন্ড (EMA50, 5m)",
                sub = if (showCall) "price ${formatPrice(price5m)} > EMA ${formatPrice(emaNow)}"
                      else "price ${formatPrice(price5m)} < EMA ${formatPrice(emaNow)}"
            ),
            ChecklistItem(
                pass = active[1],
                label = "RSI ক্রস (14, 1m)",
                sub = "RSI ${rsiNow?.let { formatPrice(it) } ?: "-"} (prev ${rsiPrev?.let { formatPrice(it) } ?: "-"})"
            ),
            ChecklistItem(
                pass = active[2],
                label = "Bollinger Band বাউন্স",
                sub = if (showCall) "low ${formatPrice(last.low)} vs lower BB ${lowerNow?.let { formatPrice(it) } ?: "-"}"
                      else "high ${formatPrice(last.high)} vs upper BB ${upperNow?.let { formatPrice(it) } ?: "-"}"
            ),
            ChecklistItem(
                pass = active[3],
                label = "স্ট্রং ক্যান্ডেল বডি",
                sub = "body ${formatPrice(signalBody)} vs avg ${formatPrice(avgBody)}"
            )
        )

        val liveClose = m1.last().close
        val prevClose = if (m1.size >= 2) m1[m1.size - 2].close else liveClose
        val changePct = if (prevClose != 0.0) (liveClose - prevClose) / prevClose * 100 else 0.0

        val chartN = 40
        return CycleResult(
            chartCandles = closedM1.takeLast(chartN),
            chartBbUpper = bb.upper.takeLast(chartN),
            chartBbLower = bb.lower.takeLast(chartN),
            liveClose = liveClose,
            changePct = changePct,
            bias = bias,
            showCall = showCall,
            checklist = checklist,
            allPass = allPass,
            lastOpenTime = last.openTime,
            lastClose = last.close
        )
    }
}
