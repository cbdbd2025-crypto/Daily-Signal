package com.confirm.signal

object SymbolLists {
    val crypto = listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")
    val forex = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/JPY")
    val oanda = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/JPY", "NZD/USD", "USD/CHF")
    val yahoo = listOf("EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "EUR/JPY", "NZD/USD", "USD/CHF")

    fun forSource(source: String): List<String> = when (source) {
        "forex" -> forex
        "oanda" -> oanda
        "yahoo" -> yahoo
        else -> crypto
    }

    fun defaultFor(source: String): String = forSource(source).first()
}
