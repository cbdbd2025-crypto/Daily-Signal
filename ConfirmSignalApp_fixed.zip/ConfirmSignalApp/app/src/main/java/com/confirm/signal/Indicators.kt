package com.confirm.signal

object Indicators {

    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val out = ArrayList<Double>(values.size)
        out.add(values[0])
        for (i in 1 until values.size) {
            out.add(values[i] * k + out[i - 1] * (1 - k))
        }
        return out
    }

    // Wilder's smoothing RSI. Returns null for indices before enough data exists.
    fun rsi(values: List<Double>, period: Int): List<Double?> {
        val out = MutableList<Double?>(values.size) { null }
        if (values.size <= period) return out

        val gains = DoubleArray(values.size - 1)
        val losses = DoubleArray(values.size - 1)
        for (i in 1 until values.size) {
            val diff = values[i] - values[i - 1]
            gains[i - 1] = maxOf(diff, 0.0)
            losses[i - 1] = maxOf(-diff, 0.0)
        }

        var avgGain = (0 until period).sumOf { gains[it] } / period
        var avgLoss = (0 until period).sumOf { losses[it] } / period
        out[period] = 100 - (100 / (1 + (if (avgLoss == 0.0) 100.0 else avgGain / avgLoss)))

        for (i in period until gains.size) {
            avgGain = (avgGain * (period - 1) + gains[i]) / period
            avgLoss = (avgLoss * (period - 1) + losses[i]) / period
            val rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            out[i + 1] = 100 - (100 / (1 + rs))
        }
        return out
    }

    data class Bands(val upper: List<Double?>, val lower: List<Double?>)

    fun bollinger(values: List<Double>, period: Int, dev: Double): Bands {
        val upper = MutableList<Double?>(values.size) { null }
        val lower = MutableList<Double?>(values.size) { null }
        for (i in period - 1 until values.size) {
            val slice = values.subList(i - period + 1, i + 1)
            val mean = slice.average()
            val variance = slice.sumOf { (it - mean) * (it - mean) } / period
            val sd = Math.sqrt(variance)
            upper[i] = mean + dev * sd
            lower[i] = mean - dev * sd
        }
        return Bands(upper, lower)
    }
}
