package com.confirm.signal.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SignalDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(signal: SignalEntity)

    @Update
    suspend fun update(signal: SignalEntity)

    @Query("SELECT * FROM signals ORDER BY time DESC")
    fun observeAll(): Flow<List<SignalEntity>>

    @Query("SELECT * FROM signals WHERE status = 'pending'")
    suspend fun getPending(): List<SignalEntity>

    @Query("DELETE FROM signals")
    suspend fun clearAll()
}
