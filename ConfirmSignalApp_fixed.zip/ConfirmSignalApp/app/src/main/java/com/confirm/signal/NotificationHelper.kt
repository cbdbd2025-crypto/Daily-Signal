package com.confirm.signal

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val SERVICE_CHANNEL_ID = "confirm_service_channel"
    const val SIGNAL_CHANNEL_ID = "confirm_signal_channel"
    const val SERVICE_NOTIF_ID = 1001

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    SERVICE_CHANNEL_ID, "ব্যাকগ্রাউন্ড মনিটরিং",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    SIGNAL_CHANNEL_ID, "সিগন্যাল অ্যালার্ট",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    enableVibration(true)
                }
            )
        }
    }

    fun buildServiceNotification(context: Context, contentText: String) =
        NotificationCompat.Builder(context, SERVICE_CHANNEL_ID)
            .setContentTitle("Confirm Signal — চলছে")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

    fun sendSignalNotification(context: Context, title: String, text: String, notifId: Int) {
        val notif = NotificationCompat.Builder(context, SIGNAL_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(notifId, notif)
    }
}
