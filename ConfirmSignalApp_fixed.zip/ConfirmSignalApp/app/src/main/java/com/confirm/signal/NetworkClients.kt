package com.confirm.signal

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

object NetworkClients {

    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetchBinanceKlines(symbol: String, interval: String, limit: Int): List<Candle> =
        withContext(Dispatchers.IO) {
            val url = "https://api.binance.com/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("Binance fetch failed: ${resp.code}")
                val body = resp.body?.string() ?: throw Exception("Empty body")
                val arr = JSONArray(body)
                val out = ArrayList<Candle>(arr.length())
                for (i in 0 until arr.length()) {
                    val k = arr.getJSONArray(i)
                    out.add(
                        Candle(
                            openTime = k.getLong(0),
                            open = k.getString(1).toDouble(),
                            high = k.getString(2).toDouble(),
                            low = k.getString(3).toDouble(),
                            close = k.getString(4).toDouble()
                        )
                    )
                }
                out
            }
        }

    suspend fun fetchTwelveDataKlines(symbol: String, interval: String, outputSize: Int, apiKey: String): List<Candle> =
        withContext(Dispatchers.IO) {
            val iv = if (interval == "1m") "1min" else "5min"
            val encodedSymbol = URLEncoder.encode(symbol, "UTF-8")
            val url = "https://api.twelvedata.com/time_series?symbol=$encodedSymbol&interval=$iv&outputsize=$outputSize&order=ASC&apikey=$apiKey"
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("Twelve Data fetch failed: ${resp.code}")
                val body = resp.body?.string() ?: throw Exception("Empty body")
                val json = JSONObject(body)
                if (json.optString("status") == "error") {
                    throw Exception(json.optString("message", "Twelve Data error"))
                }
                val values = json.getJSONArray("values")
                val out = ArrayList<Candle>(values.length())
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
                for (i in 0 until values.length()) {
                    val v = values.getJSONObject(i)
                    val time = sdf.parse(v.getString("datetime"))?.time ?: 0L
                    out.add(
                        Candle(
                            openTime = time,
                            open = v.getString("open").toDouble(),
                            high = v.getString("high").toDouble(),
                            low = v.getString("low").toDouble(),
                            close = v.getString("close").toDouble()
                        )
                    )
                }
                out
            }
        }

    suspend fun fetchOandaCandles(instrument: String, granularity: String, count: Int, token: String): List<Candle> =
        withContext(Dispatchers.IO) {
            // OANDA's free "practice" (demo) environment — real tick-derived candles, no paid plan needed.
            val url = "https://api-fxpractice.oanda.com/v3/instruments/$instrument/candles" +
                "?granularity=$granularity&count=$count&price=M"
            val req = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val errBody = resp.body?.string().orEmpty()
                    throw Exception("OANDA fetch failed: ${resp.code} $errBody")
                }
                val body = resp.body?.string() ?: throw Exception("Empty body")
                val json = JSONObject(body)
                val candlesArr = json.getJSONArray("candles")
                val out = ArrayList<Candle>(candlesArr.length())
                for (i in 0 until candlesArr.length()) {
                    val c = candlesArr.getJSONObject(i)
                    if (!c.optBoolean("complete", true) && i != candlesArr.length() - 1) continue
                    val mid = c.getJSONObject("mid")
                    val time = java.time.Instant.parse(c.getString("time")).toEpochMilli()
                    out.add(
                        Candle(
                            openTime = time,
                            open = mid.getString("o").toDouble(),
                            high = mid.getString("h").toDouble(),
                            low = mid.getString("l").toDouble(),
                            close = mid.getString("c").toDouble()
                        )
                    )
                }
                out
            }
        }

    suspend fun fetchYahooCandles(tickerSymbol: String, interval: String, range: String): List<Candle> =
        withContext(Dispatchers.IO) {
            // Unofficial Yahoo Finance chart endpoint — no key or signup, but not an official
            // public API, so it can change or get rate-limited without notice.
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$tickerSymbol" +
                "?interval=$interval&range=$range"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android) ConfirmSignalApp/1.0")
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw Exception("Yahoo fetch failed: ${resp.code}")
                val body = resp.body?.string() ?: throw Exception("Empty body")
                val json = JSONObject(body)
                val chart = json.getJSONObject("chart")
                if (!chart.isNull("error") && chart.optJSONObject("error") != null) {
                    throw Exception(chart.getJSONObject("error").optString("description", "Yahoo error"))
                }
                val resultArr = chart.getJSONArray("result")
                if (resultArr.length() == 0) throw Exception("Yahoo: কোনো ডেটা নেই")
                val result = resultArr.getJSONObject(0)
                val timestamps = result.getJSONArray("timestamp")
                val quote = result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
                val opens = quote.getJSONArray("open")
                val highs = quote.getJSONArray("high")
                val lows = quote.getJSONArray("low")
                val closes = quote.getJSONArray("close")
                val out = ArrayList<Candle>(timestamps.length())
                for (i in 0 until timestamps.length()) {
                    if (opens.isNull(i) || highs.isNull(i) || lows.isNull(i) || closes.isNull(i)) continue
                    out.add(
                        Candle(
                            openTime = timestamps.getLong(i) * 1000L,
                            open = opens.getDouble(i),
                            high = highs.getDouble(i),
                            low = lows.getDouble(i),
                            close = closes.getDouble(i)
                        )
                    )
                }
                out
            }
        }
}
