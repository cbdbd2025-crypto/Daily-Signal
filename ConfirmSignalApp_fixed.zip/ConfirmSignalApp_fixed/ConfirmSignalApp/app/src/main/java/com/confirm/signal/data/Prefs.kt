package com.confirm.signal.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("confirm_signal_prefs", Context.MODE_PRIVATE)

    var dataSource: String
        get() = sp.getString("dataSource", "crypto") ?: "crypto"
        set(v) = sp.edit().putString("dataSource", v).apply()

    var symbol: String
        get() = sp.getString("symbol", "BTCUSDT") ?: "BTCUSDT"
        set(v) = sp.edit().putString("symbol", v).apply()

    // Stored locally on-device only — never hardcode this in source code.
    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(v) = sp.edit().putString("apiKey", v).apply()

    var pollSeconds: Int
        get() = sp.getInt("pollSeconds", 1)
        set(v) = sp.edit().putInt("pollSeconds", v).apply()

    var expiryMinutes: Int
        get() = sp.getInt("expiryMinutes", 1)
        set(v) = sp.edit().putInt("expiryMinutes", v).apply()

    var maxSignalsPerDay: Int
        get() = sp.getInt("maxSignalsPerDay", 2)
        set(v) = sp.edit().putInt("maxSignalsPerDay", v).apply()

    var muted: Boolean
        get() = sp.getBoolean("muted", false)
        set(v) = sp.edit().putBoolean("muted", v).apply()

    var serviceRunning: Boolean
        get() = sp.getBoolean("serviceRunning", false)
        set(v) = sp.edit().putBoolean("serviceRunning", v).apply()

    var signalsFiredToday: Int
        get() = sp.getInt("signalsFiredToday", 0)
        set(v) = sp.edit().putInt("signalsFiredToday", v).apply()

    var lastSignalDay: String
        get() = sp.getString("lastSignalDay", "") ?: ""
        set(v) = sp.edit().putString("lastSignalDay", v).apply()

    var lastSignalBarTime: Long
        get() = sp.getLong("lastSignalBarTime", 0L)
        set(v) = sp.edit().putLong("lastSignalBarTime", v).apply()

    // Per-symbol dedup: prevents the same candle from firing twice for a given symbol,
    // without symbols accidentally blocking each other when their candle timestamps coincide.
    fun lastSignalBarTimeFor(symbol: String): Long =
        sp.getLong("lastSignalBarTime_$symbol", 0L)

    fun setLastSignalBarTimeFor(symbol: String, time: Long) {
        sp.edit().putLong("lastSignalBarTime_$symbol", time).apply()
    }
}
